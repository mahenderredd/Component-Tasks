export class EventListing {
    _id: any;
    eventName: string;
    longDes: string;
    eventDate: Date;
    venueName: string;
    mobNumber: number;
    pincode: number;
    address: string;
}
